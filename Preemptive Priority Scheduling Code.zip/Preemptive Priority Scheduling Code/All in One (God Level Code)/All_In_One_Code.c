/*

@ This is the code for "Preemptive Priority Scheduling Algorithm"

# Note: 
° BY DEFAULT this All-in-one code is of 3rd Type: 
---> 3rd Type means "Using Random No. Generator Function of C programming to get the input for Arrival Time (AT), Burst Time (BT) & Priority for each process and Keeping the Priority Preference Order as: "Bigger The Number, Higher The Priority."  


/// For understanding the full potential of this "All-in-one" code even nicely, refer my "GUIDEBOOK" which is written in the end of this code in comments.

*/




#include <stdio.h>                               //// This header will always stay uncommented wheather you're converting this All-in-one code into any of the 4 Types 

//// We're including the above header file because printf() & scanf() functions which we're using in the code are present in this header file 


#include <stdlib.h> 
#include <time.h> 

//// For converting this "All-in-one" code into 1st & 2nd Type, comment out these 2 above header files, 1st one is the <stdlib.h> one and the other one is <time.h>, beacuse we're not using these two header files in 1st and 2nd Type of code

//// & While converting this "All-in-one" code into 3rd & 4th Type, uncomment the above 2 header files <stdlib.h> and the <time.h> one, because the functions which we're using in the 3rd and 4th Type of this "All-in-one" code are present in the above 2 header files. 



// ---------------------------------------------------------------



/// Like rand() & srand() are the functions which are used together in 3rd and 4th Type of this "All-in-one" code, to generate unique random no.s every time we run the code and these two functions are present in "Standard Library" of C language & that's why we're including this <stdlib.h> header file

/// & time() function is the function which is used as a parameter for srand() function or we can just say that the time() function is used as the seed value for random no. generation function the rand() function, because for generating a random no. sequence which is every time unique we need a seed value that is changing everytime and time() function of C language is the function which calculates the no. of seconds elapsed from 1st January 1970 till now and that's the reason that every time when we call this time() function we get a new value from it, because it's still counting the no. of seconds while I am writing this comment. And this time() function is present in <time.h> header file. 



// ---------------------------------------------------------------


//// Wheather you're converting this All-in-one code into any of the Types this section will always stay uncommented 


/// We want minimum and maximum finding functions for this code & The min() and max() functions are not part of the standard C library. 

/// So, that's why we're defining them here on our own so that we can use them in our code ahead. 


int min(int a, int b)
{
    if (a < b)
    {
        return a;
    }
    else
    {
        return b;
    }
}

int max(int a, int b)
{
    if (a > b)
    {
        return a;
    }
    else
    {
        return b;
    }
}

struct process
{
    int pid;
    int arrival_time;
    int burst_time;
    int priority;
    int start_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
    int response_time;
};

int main()
{   
    int n;
    struct process p[100];
    float avg_turnaround_time;
    float avg_waiting_time;
    float avg_response_time;
    float cpu_utilization;
    float throughput;

    int total_turnaround_time = 0;
    int total_waiting_time = 0;
    int total_response_time = 0;
    int total_idle_time = 0;

    int burst_remaining[100];
    int is_completed[100] = {0};


    // --------------------------------------------------------------- 

    
    //// Same goes for this section also, Wheather you're converting this "All-in-one" code into any of the Types this section will always stay uncommented 


    printf("\n");
    printf("# Enter the number of processes: ");
    scanf("%d", &n);
    printf("\n");

    if(n>100){
        printf("\n");
        printf("---> Input value for \"No. of processes\" cannot me more than 100. \n");
        printf("\n");
        return 0;
    }
    else if(n<0){
        printf("\n");
        printf("---> You have entered the input for \"No. of processes\" as a -ve number. \n");
        printf("---> \"No. of processes\" cannot be -ve, therefore this code has stopped it's execution. \n");
        printf("---> Try Again!! By giving input for \"No. of processes\" as a +ve number. \n");
        printf("\n");
        return 0;
    }
    else if(n==0){
        printf("\n");
        printf("---> You have entered the input for \"No. of processes\" as 0. \n");
        printf("---> So, there are no processes in the ready queue which has to be processed by the scheduling algorithm, therefore this code has stopped it's execution. \n");
        printf("\n");
        return 0;
    }


    // --------------------------------------------------------------- 


    //// Keep this whole section commented when you're converting the "All-in-one" code into 1st or 2nd Type
    //// & Uncomment this whole section if you're converting the "All-in-one" code into 3rd or 4th Type 


    srand(time(NULL));

    for (int i = 0; i < n; i++)
    {
        p[i].arrival_time = rand()%15;                          // Arrival Time will be in the range 0-14, I have taken a small range so that checking the output of the algo. manually is easy, you can change it if you want, just change the value of no. after the Modulus (%) symbol 

        p[i].burst_time = (rand()%15) + 1;                      // Burst Time will be in the range 1-15,I removed 0 from range because for a process to be in ready queue, it cannot have 0 Burst time, I have taken a small range, you can change it if you want, just change the value of no. after the Modulus (%) symbol 

        p[i].priority = rand()%15;                              // Priority will be in the range 0-14, I have taken a small range, you can change it if you want, just change the value of no. after the Modulus (%) symbol and that will decide the range of new randomly generated no.s 

        p[i].pid = i + 1;

        burst_remaining[i] = p[i].burst_time;
    }


    // --------------------------------------------------------------- 


    //// Keep this whole section Uncommented when you're converting the "All-in-one" code into 1st or 2nd Type 
    //// & Comment out this whole section if you're converting the "All-in-one" code into 3rd or 4th Type


    /*
    for (int i = 0; i < n; i++)
    {
        int x, y, z;

        printf("* Enter arrival time of process %d: ", i + 1);
        scanf("%d", &x);

        if(x>=0){
            p[i].arrival_time = x;
        }
        else{
            printf("\n");
            printf("---> You have entered a -ve no. as a input in arrival time's field. \n");
            printf("---> & Arrival time cannot be negative. \n");
            printf("---> So, Try Again!! And this time for successful execution of code, Either give 0 or a +ve no. as a input in arrival time's field. \n");
            printf("\n");
            return 0;
        }

        printf("* Enter burst time of process %d: ", i + 1);
        scanf("%d", &y);

        if(y>=1){
            p[i].burst_time = y;
        }
        else if(y==0){
            printf("\n");
            printf("---> You have entered 0 as a input in burst time's field. \n");
            printf("---> & if a process wants to get processed by the scheduling algorithm than it cannot have 0 as it's burst time. \n");
            printf("---> Because having 0 as a burst time simply means that the process has already completed it's execution. \n");
            printf("---> So, Try Again!! And this time for successful execution of code, Either give 1 or any other +ve no. as a input in burst time's field. \n");
            printf("\n");
            return 0;
        }
        else{
            printf("\n");
            printf("---> You have entered a -ve no. as a input in burst time's field. \n");
            printf("---> & Burst time cannot be negative. \n");
            printf("---> So, Try Again!! And this time for successful execution of code, Either give 1 or any other +ve no. as a input in burst time's field. \n");
            printf("\n");
            return 0;
        }

        printf("* Enter priority of the process %d: ", i + 1);
        scanf("%d", &z);
        */


        // --------------------------------------------------------------- 


        //// When you're converting this All-in-one code into 2nd Type at that time keep this section uncommented otherwise keep it always commented

        /*
        if(z>10000000){
            printf("\n");
            printf("---> You have entered a no. greater than \"10000000\" as a input in priority's field. \n");
            printf("---> & Priority cannot be more than \"10000000\" for this code in case of \"Priority Preference Order: Smaller The Number, Higher The Priority.\" \n");
            printf("---> So, Try Again!! And this time for successful execution of code, Either give 0 or a +ve no. in the range of 1 to 10000000 as a input in priority's field. \n");
            printf("\n");
            return 0;
        }
        */


        // --------------------------------------------------------------- 

        
        //// Keep this whole section Uncommented when you're converting the All-in-one code into 1st or 2nd Type 
        //// & Comment out this whole section if you're converting the All-in-one code into 3rd or 4th Type

        /*
        if(z>=0){
            p[i].priority = z;
        }
        else{
            printf("\n");
            printf("---> You have entered a -ve no. as a input in priority's field. \n");
            printf("---> & Priority cannot be negative. \n");
            printf("---> So, Try Again!! And this time for successful execution of code, Either give 0 or a +ve no. as a input in priority's field. \n");
            printf("\n");
            return 0;
        }

        p[i].pid = i + 1;

        burst_remaining[i] = p[i].burst_time;
        printf("\n");
    }
    */


    // ------------------------------------------------------------------------------------------------------------------------------ 

    //// In whichever Type you're converting this All-in-one code into, you have to keep this whole section always uncommented 

    //// But Only In this section we have to make a little bit changes in value of a single variable and we have to change a operator depending upon into which Type you're converting this All-in-one code into, refer the further comments for the changes  


    int current_time = 0;
    int completed = 0;
    int prev = 0;

    while (completed != n)
    {
        int idx = -1;
        int mx = -1;                //// Here if you're converting this All-in-one code into Type 1 or 3 then keep this "mx" variable's value as "-1" & if you're converting this All-in-code into Type 2 & 4 then we just have to change the value of this "mx" varibale to "10000000" 

        for (int i = 0; i < n; i++)
        {

            if (p[i].arrival_time <= current_time && is_completed[i] == 0)
            {

                if (p[i].priority > mx)       //// Here if you're converting this All-in-one code into Type 1 or 3 then keep the comparison operator inside the if condition as "greater than symbol (>)" & if you're converting this All-in-code into Type 2 & 4 then we just have to change the comparison operator inside the if condition to "less than symbol (<)"
                {

                    mx = p[i].priority;
                    idx = i;
                }

                if (p[i].priority == mx)
                {

                    if (p[i].arrival_time < p[idx].arrival_time)
                    {

                        mx = p[i].priority;
                        idx = i;
                    }
                }
            }
        }


        // ------------------------------------------------------------------------------------------------------------------------------ 


        //// For this section as well, into whichever Type you're converting this All-in-one code into, you have to keep this whole section always uncommented 


        if (idx != -1)
        {

            if (burst_remaining[idx] == p[idx].burst_time)
            {

                p[idx].start_time = current_time;
                total_idle_time = total_idle_time + p[idx].start_time - prev;
            }

            burst_remaining[idx] = burst_remaining[idx] - 1;
            current_time++;
            prev = current_time;

            if (burst_remaining[idx] == 0)
            {

                p[idx].completion_time = current_time;
                p[idx].turnaround_time = p[idx].completion_time - p[idx].arrival_time;
                p[idx].waiting_time = p[idx].turnaround_time - p[idx].burst_time;
                p[idx].response_time = p[idx].start_time - p[idx].arrival_time;

                total_turnaround_time = total_turnaround_time + p[idx].turnaround_time;
                total_waiting_time = total_waiting_time + p[idx].waiting_time;
                total_response_time = total_response_time + p[idx].response_time;

                is_completed[idx] = 1;
                completed++;
            }
        }

        else
        {
            current_time++;
        }
    }

    int min_arrival_time = 10000000;
    int max_completion_time = -1;

    for (int i = 0; i < n; i++)
    {

        min_arrival_time = min(min_arrival_time, p[i].arrival_time);
        max_completion_time = max(max_completion_time, p[i].completion_time);
    }

    avg_turnaround_time = (float)total_turnaround_time / n;
    avg_waiting_time = (float)total_waiting_time / n;
    avg_response_time = (float)total_response_time / n;
    cpu_utilization = ((max_completion_time - total_idle_time) / (float)max_completion_time) * 100;
    throughput = (float) n / (max_completion_time - min_arrival_time);

    printf("#PID\t  AT\t  BT\t  Pri.\t  ST\t  CT\t  TAT\t  WT\t  RT\t  \n");

    for (int i = 0; i < n; i++)
    {
        printf("%d\t  %d\t  %d\t  %d\t  %d\t  %d\t  %d\t  %d\t  %d\t  \n", i + 1, p[i].arrival_time, p[i].burst_time, p[i].priority, p[i].start_time, p[i].completion_time, p[i].turnaround_time, p[i].waiting_time, p[i].response_time);
    }

    printf("\n");

    printf("@ Average Turnaround Time = %.2f \n", avg_turnaround_time);
    printf("@ Average Waiting Time = %.2f \n", avg_waiting_time);
    printf("@ Average Response Time = %.2f \n", avg_response_time);
    printf("@ CPU Utilization = %.2f%% \n", cpu_utilization);
    printf("@ Throughput = %.2f processes/unit time \n", throughput);

    printf("\n");

    return 0;
}


// ------------------------------------------------------------------------------------------------------------------------------

/*


-------- DESCRIPTION OF ABOVE CODE --------


° So, The above code is of "Preemptive Priority Scheduling Algorithm"
---> But, it is a All-in-one code.


° Now what do I mean by All-in-one code???
---> Well, for the above "Preemptive Priority Scheduling Algorithm" code, we can say there are overall 4 types:

1st) Taking Input From User for Arrival Time (AT), Burst Time (BT) & Priority (Pri) for each process and Keeping the Priority Preference Order as: "Bigger The Number, Higher The Priority".

2nd) Taking Input From User for Arrival Time (AT), Burst Time (BT) & Priority (Pri) for each process and Keeping the Priority Preference Order as: "Smaller The Number, Higher The Priority".

3rd) Using Random No. Generator Function of C programming to get the input for Arrival Time (AT), Burst Time (BT) & Priority for each process and Keeping the Priority Preference Order as: "Bigger The Number, Higher The Priority".

4th) Using Random No. Generator Function of C programming to get the input for Arrival Time (AT), Burst Time (BT) & Priority for each process and Keeping the Priority Preference Order as: "Smaller The Number, Higher The Priority".


// ---------------------------------------------------------------


# So, Now as I have explained above all the 4 types of "Preemptive Priority Scheduling Algorithm" codes, which can be made by using this All-in-one code:
---> Then I will love to make this concept of "All-in-one" code even clearer to you.
---> The above code can be converted into any of these 4 types of "Preemptive Priority Scheduling Algorithm" codes, by commenting out pair of "different-different" lines selectively in a set manner.


# Out of all these "4 Types" of this code which I have mentioned above:
*** BY DEFAULT: I am keeping this code as of "3rd Type": ***

° Which means "BY DEFAULT" type of this above code is:
3rd) ---> Using Random No. Generator Function of C programming to get the input for Arrival Time (AT), Burst Time (BT) & Priority for each process and Keeping the Priority Preference Order as: "Bigger The Number, Higher The Priority".


// ---------------------------------------------------------------



-------- GUIDEBOOK FOR USING THE ABOVE CODE MOST OPTIMALLY --------

@ If you don't want to change the BY DEFAULT type of this above code, which means you want to use the BY DEFAULT Type the 3rd Type only, then just don't mess with the comments and run the code normally, it's already ready to use.

@@@ But if you want to switch the above code's type to other types of this code, then:


# 1st of all before starting to convert this above code into any other type, let's come to the starting point, from where we have to start conversion of this "All-in-one" code into any of the above 4 types you want.

### Any time you want to change the type of this code, just don't forget to come to the starting point 1st, it will be a lot easier than to convert this code into any type you want to convert it into, now let's move ahead:


# For coming to this starting point which I am talking about. Just remove all the "CODING LINE" comments of the above code, Don't remove the "dashed line comments" which look like this "// -------- ", these comments are just used for segregating different SECTIONS of the above code & also don't uncomment this paragraph section which is written after final "return 0" statement of "int main()" function and one more thing, also don't uncomment the instructions which I have written in the above code which helps you out while connverting this All-in-one code into different Types.

# JUST UNCOMMENT ALL THE "CODING LINES" OF THE ABOVE CODE, THAT'S IT, now you have Reached the starting point from where we will start our conversion of this "All-in-one" code.


# Now, After reaching the starting point, Scroll through the whole code up & down and traverse the whole code throughly SECTION by SECTION:

---> Whichever pair of lines or SECTIONS are needed to be commented out to convert this "All-in-one" code into that specific "X Type", Infront of all those lines of code or we can also say inside all of these SECTIONS of this code I have written that these has to be kept commented or uncommented for converting this code into the "X type" which you want to convert it into.

---> All these "Code Type Conversion Comments" are written using "////" 4 forward slashes so that you can differentiate the "Code Type Conversion Comments" easily and don't confuse them with the "///" 3 forward slash comments & the "//" 2 forward slash comments.

---> "///" 3 forward slash comments are used to describe functionalities of functions, header flies and different things of the code and where else on the other hand "////" 4 forward slash comments are used to write the "Code Type Conversion Comments" & As I have also shown above the "//" 2 foward slash comments are used with "DASHED LINES" for segregating this code into different "SECTIONS".

---> And also if there is any change in the value of any variable or any change in any of the operators in any line of this "All-in-one" code, then infront of those lines also I have mentioned in comments that what should be the value of this variable for this specific "X Type" or what operator should be used in this line for this specific "X-Type"


@ That's it from my side on "GUIDING YOU" to tell you that "HOW TO USE THIS ALL-IN-ONE CODE EFFICIENTLY" and I hope it "HELPED" ;)



// ---------------------------------------------------------------


-------- FULL FORMS & FORMULAS --------


# Full Forms for the Acronyms & the Abbrevations which I have used above in code:

i) PID - Process ID
ii) AT - Arrival Time
iii) BT - Burst Time
iv) Pri. - Priority
v) ST - Start Time
vi) CT - Completion Time
vii)  TAT - Turn Around Time
viii) WT - Waiting Time
ix) RT - Response Time



# Formulas for calculating the Turn Around Time (TAT), Waiting Time (WT), Response Time (RT), CPU Utilization & Throughput:

a) TAT = CT - AT
b) WT = TAT - BT
c) RT = ST - AT

d) CPU Utilization Percentage = (Total amount of time process are using the CPU / Real Amount of Time Passed) * 100

or

# CPU Utilization Percentage's Formula Can be Also Written As:

d) CPU Utilization Percentage = ((Real Amount of Time Passed - Total Amount of Time CPU Stayed Idle Until All Processes were Processed) / Real Amount of Time Passed) * 100

e) Throughput = No. of Processes Processed / Total Real Amount of Time Passed



// ---------------------------------------------------------------


-------- REPORT --------


@ Introduction of Scheduling Algorithms:

* Scheduling Algorithms are algorithms which are used for distributing resources among parties which simultaneously and asynchronously request them.

* The main purposes of scheduling algorithms are to minimize resource starvation and to ensure fairness amongst the parties utilizing the resources.

* Scheduling deals with the problem of deciding which of the outstanding requests is to be allocated resources. There are many different scheduling algorithms like: First Come First Serve Scheduling Algo., Shortest Remaining Time First Algo., Priority Scheduling Algo., Round Robin Scheduling Algo., etc.

* Above we have written code of "Preemptive Priority Scheduling Algorithm".


// ---------------------------------------------------------------


@ How The Results Generated by "Preemptive Priority Scheduling Algorithm" are Better than "Round Robin Algorithm":

* In the "Preemptive Priority Scheduling Algorithm", each process is assigned a priority value, and the CPU is allocated to the process with the highest priority for execution. If a higher-priority process becomes available, the running process is preempted to allow the higher-priority process to execute. This ensures that high-priority processes are executed with minimal delay, while low-priority processes are executed only when no higher-priority process is waiting. This scheduling algorithm is particularly effective in systems that require quick response times for high-priority processes.


* In Round Robin Algorithm, each process is given a fixed time slice, and the CPU is allocated to each process in a circular manner. If a process completes its time slice, it is preempted and the next process in the queue is given the CPU.



# "Preemptive Priority Scheduling Algorithm" has the following advantages over "Round Robin Algorithm": 
(i) Better response time for high-priority processes
(ii) Better resource utilization, resources are utilized effectively, and there is less wastage.
(iii) More suitable for real-time systems 


# On the other hand, "Round Robin Algorithm" has the following advantages over "Preemptive Priority Scheduling Algorithm": 
(i) Fairness, as it gives each process an equal share of the CPU time, regardless of its priority. 
(ii) Predictable behaviour, Round Robin Algorithm has a predictable behaviour, which makes it easier to analyze and tune the system. 


// ---------------------------------------------------------------


@ Example:

# For the above "BY DEFAULT: Type-3 Code", When we run this program, and give input for "No. of Processes: ", the random no. generator will assign values to each process for Arrival Time, Burst Time & For the Priority in the given range which is set by the coder, by me it's here 0-14 for AT, 1-15 for BT & 0-14 for Priority & After getting the Input it will perform all the Operations and Calculate rest of the fields required, which are ST, CT, TAT, WT, RT, Avg. TAT, Avg. WT, Avg. RT, CPU Utilization & Througput.

Ex:
# Enter the number of processes: 7

#PID      AT      BT      Pri.    ST      CT      TAT     WT      RT      
1         11      4       12      18      22      11      7       7       
2         2       3       9       33      36      34      31      31      
3         14      13      8       41      54      40      27      27      
4         2       4       11      2       6       4       0       0       
5         4       15      10      6       33      29      14      2       
6         10      8       13      10      18      8       0       0       
7         13      5       8       36      41      28      23      23      

@ Average Turnaround Time = 22.00 
@ Average Waiting Time = 14.57 
@ Average Response Time = 12.86 
@ CPU Utilization = 96.30% 
@ Throughput = 0.13 processes/unit time


### And when we manually perform "Preemptive Priority Scheduling Algorithm" calculations and take out answers of all these fields, all the values are exactly same. So, this just confirms that out that our "Preemptive Priority Scheduling Algorithm" code is working totally fine. ;)



@ Advantages of "Preemptive Priority Scheduling Algorithm":
(a) Good way to ensure processes with higher priorities are handled first. 
(b) Choice of running task reconsidered after each interruption. 
(c) Good when the resources are limited and priorities for each process are defined beforehand. 



@ Disadvantages of "Preemptive Priority Scheduling Algorithm": 
(a) Low priority processes will be lost if the computer crashes. 
(b) Processes with lower priority may be starved. 
(c) The scheduler spends more time suspending the ongoing job, switching the context, and dispatching the new incoming task.



-------- THE END --------


*/